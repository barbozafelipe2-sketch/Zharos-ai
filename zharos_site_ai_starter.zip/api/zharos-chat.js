// api/zharos-chat.js
export default async function handler(req, res) {
  // Basic CORS (you may restrict Origin below)
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  if (req.method === 'OPTIONS') return res.status(200).end();

  if (req.method !== 'POST') return res.status(405).json({ error: 'Use POST' });

  try {
    const { messages = [], system, temperature = 0.6, model = 'gpt-4o-mini' } = req.body || {};
    if (!Array.isArray(messages)) return res.status(400).json({ error: 'messages precisa ser um array' });

    // OPTIONAL: Lock to your domain (uncomment & edit)
    // const ref = req.headers.referer || '';
    // if (!ref.includes('SEU-DOMINIO.com')) return res.status(403).json({ error: 'forbidden' });

    const r = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model,
        temperature,
        messages: [
          ...(system ? [{ role: 'system', content: system }] : []),
          ...messages
        ]
      })
    });

    const text = await r.text();
    if (!r.ok) return res.status(r.status).send(text);
    const data = JSON.parse(text);

    const reply = data?.choices?.[0]?.message?.content ?? '';
    res.status(200).json({ reply, raw: data });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'proxy_error', detail: String(e) });
  }
}
