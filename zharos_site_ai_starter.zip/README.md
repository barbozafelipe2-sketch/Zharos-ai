# ZHAROS • Starter (Vercel + Widget)

Pacote mínimo para rodar um chat Zharos no seu site (inclui demo e snippet para Squarespace).

## O que vem
- `api/zharos-chat.js` — **proxy seguro** (Vercel) para a OpenAI (não expõe a chave no front).
- `vercel.json` — roteamento simples.
- `public/index.html` — página demo local do widget.
- `public/widget-snippet.html` — código para colar no **rodapé do seu site**.
- `public/zharos_brain.json` — “cérebro-base” (pode editar e hospedar no seu domínio).

---

## 1) Deploy no Vercel
1. Crie um **novo projeto** no Vercel (importando este diretório/zip ou conectando um repositório).
2. Em **Settings → Environment Variables**, adicione:
   - `OPENAI_API_KEY` = sua chave da OpenAI.
3. Faça **Deploy**.
4. Sua rota deverá estar assim: `https://SEU-PROJ.vercel.app/api/zharos-chat`

**Teste** via curl:
```bash
curl -X POST https://SEU-PROJ.vercel.app/api/zharos-chat   -H "Content-Type: application/json"   -d '{ "system": "Você é o Zharos.", "messages": [{"role":"user","content":"Olá?"}] }'
```

Se vier JSON com `reply`, está funcionando.

> **CORS** já está liberado por padrão. Para travar por domínio, edite `api/zharos-chat.js` e descomente a checagem de `referer`.

---

## 2) Colocar no seu site (Squarespace / qualquer CMS)
1. Abra `public/widget-snippet.html` e **copie o conteúdo inteiro**.
2. Cole no **rodapé do site** (Squarespace → Settings → Advanced → Code Injection → Footer).
3. Troque `ENDPOINT_URL` pela URL do seu projeto Vercel: `https://SEU-PROJ.vercel.app/api/zharos-chat`.
4. (Opcional) Hospede `zharos_brain.json` no seu domínio e descomente a linha de `fetch` no snippet.

---

## 3) Personalizar o “cérebro”
Edite `public/zharos_brain.json` (campo `system`). Você pode incluir:
- Personalidade e tom.
- Regras do seu ecossistema (AERA / KAIROS / Friday / Marbelous).
- Limites de segurança (ex.: nunca expor chaves, etc.).

Depois, hospede esse arquivo no seu domínio e carregue-o no widget (linha comentada no snippet).

---

## 4) Problemas comuns
- **401/403** → faltou `OPENAI_API_KEY` ou endpoint errado.
- **Erro no site** → confira se `ENDPOINT_URL` aponta para o Vercel certo.
- **Custo** → mude `model` em `api/zharos-chat.js` para um mais barato (ex.: `gpt-4o-mini`).

---

## 5) Segurança
- A chave OpenAI **fica no backend** (Vercel). Não exponha no front.
- Se quiser restringir por domínio, ative a checagem de `referer`.
- Para rate limit, você pode usar Vercel Edge Middleware ou adicionar verificação de token própria.

Bom deploy! 🚀
